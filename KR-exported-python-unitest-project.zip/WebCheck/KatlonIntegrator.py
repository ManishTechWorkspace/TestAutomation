# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

class KatlonIntegrator(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome(executable_path=r'')
        self.driver.implicitly_wait(30)
        self.base_url = "https://www.google.com/"
        self.verificationErrors = []
        self.accept_next_alert = True
    
    def test_katlon_integrator(self):
        driver = self.driver
        driver.get("https://katalon.com/visual-testing")
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div/div").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div[2]/div").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div[2]/div").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div[3]/div").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div[3]/div").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div[4]/div").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div/div[5]/div/div[4]/div").click()
        driver.find_element_by_xpath("//div[@id='katalon_header']/section[2]/div/div/div/a/div/div").click()
        driver.get("https://katalon.com/integrations")
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[2]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[3]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[4]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[5]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[6]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[7]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[8]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[9]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[10]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[12]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[14]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[17]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[16]").click()
        driver.find_element_by_xpath("//div[@id='__next']/main/div[2]/div[3]/div[55]/div[2]/div[3]/div[15]").click()
        driver.find_element_by_xpath("//div[@id='katalon_header']/section[2]/div/div").click()
        driver.find_element_by_xpath("//img[@alt='Katalon']").click()
        driver.get("https://katalon.com/")
    
    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e: return False
        return True
    
    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException as e: return False
        return True
    
    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
